CA ca;

int tamanho = 600;

void setup() {
    size(600,400);
    frameRate(20);
    background(255);
    strokeWeight(0.4);
    int[] ruleset = {1,1,1,1,1,1,1,0};
    ca = new CA(ruleset);
}

void draw() {
    ca.render();
    ca.generate();  
    //  if (ca.finished()) {
    //    background(255);
    //ca.randomize();
    //ca.restart();
    //  }
}

void mousePressed() {
    background(255);
    ca.randomize();
    ca.restart();
}

class CA {
    int[] cells; // linha de células
    int generation; // número da iteração
    int scl; // tamanho de cada célula
    int[] rules; // regras para o autômato celular
    
    CA(int[] r) {
        rules = r;
        scl = 10;
        cells = new int[tamanho/scl];
        restart();
    }
    
    CA() {
        scl = 10;
        cells = new int[tamanho/scl];
        randomize();
        restart();
    }
    
    int applyRules (int a, int b, int c) {
        if (a == 1 && b == 1 && c == 1) return rules[0];
        if (a == 1 && b == 1 && c == 0) return rules[1];
        if (a == 1 && b == 0 && c == 1) return rules[2];
        if (a == 1 && b == 0 && c == 0) return rules[3];
        if (a == 0 && b == 1 && c == 1) return rules[4];
        if (a == 0 && b == 1 && c == 0) return rules[5];
        if (a == 0 && b == 0 && c == 1) return rules[6];
        if (a == 0 && b == 0 && c == 0) return rules[7];
        return 0;
    }
    
    void randomize() {
        for (int i = 0; i < 8; i++) {
            rules[i] = int(random(2));
        }
    }
    
    void restart() {
        for (int i = 0; i < cells.length; i++) {
            cells[i] = 0;
        }
        cells[cells.length/2] = 1;
        generation = 0;
    }
    
    void generate() {
        int[] nextgen = new int[cells.length];
        
        for (int i = 0; i < cells.length; i++) {
            int esquerda, atual, direita;
            
            // vizinho esquerda
            if(i==0){ 
                esquerda = cells[cells.length-1];
            }
            else{
                esquerda = cells[i-1];   
            }
            
            // estado corrente
            atual = cells[i];       
            
            // vizinha direita
            if(i==cells.length-1){ 
                direita = cells[0];
            }
            else{
                direita = cells[i+1]; 
            }
            
            // computa proxima geracao
            nextgen[i] = this.applyRules(esquerda,atual,direita); 
        }
        cells = nextgen;
        generation++;
    }
    
    void render() {
        for (int i = 0; i < cells.length; i++) {
            if (cells[i] == 1) {
                stroke(255);
                fill(0);
            } else {
                stroke(0);
                fill(255);
            }
            
            rect(i*scl,generation*scl, scl,scl);
        }
    }
    
    boolean finished() {
        if (generation > height/scl) {
            return true;
        } else {
            return false;
        }
    }
}